# coding: utf-8

import os
import sys
import math
from multiprocessing import Process
 
import threading

def named_pipe(fifo_path):
    # 创建named pipe
    if (os.access(fifo_path, os.F_OK) == False and os.name !='nt') :
        os.mkfifo(fifo_path)
    else:
        os.mknod (fifo_path)
    fifo_read_only = os.open(fifo_path, os.O_RDONLY)
    
    while True:
        data = os.read(fifo_read_only, 4)
        length = int.from_bytes(data,'little')
        msg = os.read(fifo_read_only,length) .decode("utf-8")
        if msg == "q":      
            break
        print(msg)
    
    os.close(fifo_read_only)
    # 移除named pipe
    os.unlink(fifo_path)
t = threading.Thread(target=named_pipe, name='named_pipe', args=("/tmp/fifo_pi",))
t.start()
msg = input("请输入您的指令：")