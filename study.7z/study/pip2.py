# coding: utf-8

import os
import sys
import math
fifo_path ="/tmp/fifo_pi"
# 创建named pipe 
if os.access(fifo_path, os.F_OK) == False:
    os.mkfifo(fifo_path)
fifo_write_only = os.open(fifo_path, os.O_WRONLY)

while True:
    msg = input("请输入您的指令：")
    data = msg.encode("utf-8")
    length = len(data)
    os.write(fifo_write_only, length.to_bytes(4,'little') )
    os.write(fifo_write_only, data )
os.close(fifo_write_only)