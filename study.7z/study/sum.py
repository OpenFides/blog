
sum = 0
    
# for i in range(1,101):
#     # print(i)
#     if i % 2 == 1:
#         continue

#     sum += i
#     # break
#     # sum = sum +i

# print(sum)


# sum = 0

# for i in range(0,101,2):
#     print(i)
#     # if i % 2 == 1:
#     #     continue

#     sum += i
#     # break
#     # sum = sum +i

# print(sum)

# i =1
# while(i<101):
#     print(i)
#     sum +=i
#     i+=2
#     continue


# print(sum)
# print('end')
count=0
sum = 0
for k in range(0, 105,5):
    # print(k)
    count +=1
    # 5的倍数则求和
    sum += k
print(sum)
print(count)
sum = 0

count=0
k = 0
while(k < 101):
    count+=1
    sum += k
    k += 5
    # print(k)
 
print(count)
print(sum)
 
 
pi = 314 