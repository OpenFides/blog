sum = 0
for k in range(0, 101):
    if k % 3 == 0:
        for f in range(0, 101):
            if f % 5 == 0:
                sum += k*f
print(sum)


#

sum = 0
for k in range(0, 101, 3):
    for f in range(0, 101, 5):
       
        sum += k*f
print(sum)
